# Third-party notices

The current editor UI and project code are original project files. No third-party JavaScript runtime library is bundled.

The Android application uses Android platform APIs and Android Gradle Plugin at build time. Their respective licenses remain with their owners.
