#!/usr/bin/env python3
"""Small source sanity check for the self-contained Haraka editor."""
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
html = root / "app/src/main/assets/index.html"
source = html.read_text(encoding="utf-8")
blocks = re.findall(r"<script>(.*?)</script>", source, flags=re.S)
if not blocks:
    raise SystemExit("No inline editor script found")
js_file = Path("/tmp/haraka-editor-check.js")
js_file.write_text(blocks[0], encoding="utf-8")
try:
    subprocess.run(["node", "--check", str(js_file)], check=True)
except FileNotFoundError:
    raise SystemExit("Node.js is required for this check")

required = [
    "function addFrame()", "function addCharacter()", "function addTween()",
    "function exportPNG()", "function exportGIF()", "function exportVideo()",
    "function openProjectFile(file)", "function importBackground(file)",
]
missing = [token for token in required if token not in source]
if missing:
    print("Missing editor functions:", ", ".join(missing), file=sys.stderr)
    raise SystemExit(1)
print("Editor source check passed: JavaScript syntax and required feature hooks found.")
